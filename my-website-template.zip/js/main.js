document.getElementById("clickMe")?.addEventListener("click", () => {
  alert("JavaScript is working!");
});
